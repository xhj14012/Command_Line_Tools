This is a win7-10 activator bash set
enable server in bat file first(remove "::")
run bat and follow the guide
win8 version unchecked

check https://github.com/xhj14012/Command_Line_Tools for undate